package com.ghamari.vahab.pokemon.main.model;

/**
 * Created by VahabGh on 5/28/2019.
 */
public abstract class PokemonDetailItem {
    public abstract PokemonDetailItemType getType();
}
