package com.ghamari.vahab.pokemon.main.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ghamari.vahab.pokemon.R;
import com.ghamari.vahab.pokemon.main.model.Pokemon;
import com.ghamari.vahab.pokemon.main.presenter.PokemonDetailPresenter;

/**
 * Created by VahabGh on 5/28/2019.
 */
public class PokemonDetailFragment extends Fragment implements PokemonDetailView<PokemonDetailPresenter> {

    private View view;
    private PokemonDetailPresenter presenter;
    private String pokemonUrl;

    public PokemonDetailFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_pokemons, container, false);
        presenter = createPresenter();
        pokemonUrl = getPokemonUrl();
        presenter.getPokemonDetail(pokemonUrl);
        return view;
    }

    private String getPokemonUrl() {
        Bundle arguments = getArguments();
        if (arguments.containsKey("POKEMON_URL"))
            return arguments.getString("POKEMON_URL");
        return "";
    }

    @Override
    public PokemonDetailPresenter createPresenter() {
        return new PokemonDetailPresenter(this);
    }

    @Override
    public void setPokemonDetail(Pokemon pokemon) {
        Log.i("PokemonDetail",pokemon.toString());
    }

    @Override
    public void onFailed(String exception) {

    }

    @Override
    public void showProgress() {

    }

    @Override
    public void hideProgress() {

    }
}
