package com.ghamari.vahab.pokemon.main.view;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ghamari.vahab.pokemon.R;
import com.ghamari.vahab.pokemon.main.Utility.CustomTextView;
import com.ghamari.vahab.pokemon.main.model.Pokemon;

import java.util.List;

/**
 * Created by VahabGh on 5/28/2019.
 */
public class PokemonsAdapter extends RecyclerView.Adapter<PokemonsAdapter.MyViewHolder> {

    private List<Pokemon> pokemons;
    private OnItemClickListener onItemClickListener;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public CustomTextView name;

        public MyViewHolder(View view) {
            super(view);
            name = (CustomTextView) view.findViewById(R.id.name);
        }

        public void bind(final Pokemon item, final OnItemClickListener listener) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    listener.onItemClick(item);
                }
            });
        }
    }


    public PokemonsAdapter(List<Pokemon> pokemons,OnItemClickListener onItemClickListener) {
        this.pokemons = pokemons;
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.pokemon_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Pokemon pokemon = pokemons.get(position);
        holder.name.setText(pokemon.getName());
        holder.bind(pokemon,onItemClickListener);
    }

    @Override
    public int getItemCount() {
        return pokemons.size();
    }

    public interface OnItemClickListener {
        void onItemClick(Pokemon item);
    }
}

