package com.ghamari.vahab.pokemon.main.view.viewholders;

import android.view.View;

import com.ghamari.vahab.pokemon.main.model.PokemonDetailItem;
import com.ghamari.vahab.pokemon.main.view.PokemonDetailItemViewHolder;

/**
 * Created by VahabGh on 5/29/2019.
 */
public class PokemonHeader extends PokemonDetailItemViewHolder {

    public PokemonHeader(View itemView) {
        super(itemView);
    }

    @Override
    public void bind(PokemonDetailItem pokemonDetailItem) {

    }
}
