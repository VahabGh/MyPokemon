package com.ghamari.vahab.pokemon.main.view.viewholders;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.ghamari.vahab.pokemon.main.model.PokemonDetailItem;
import com.ghamari.vahab.pokemon.main.view.PokemonDetailItemViewHolder;

/**
 * Created by VahabGh on 5/29/2019.
 */
public class PokemonStatViewHolder extends PokemonDetailItemViewHolder {

    public PokemonStatViewHolder(View itemView) {
        super(itemView);
    }

    @Override
    public void bind(PokemonDetailItem pokemonDetailItem) {

    }
}
