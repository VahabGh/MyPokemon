package com.ghamari.vahab.pokemon.main.model;

/**
 * Created by VahabGh on 5/29/2019.
 */
public class Header extends PokemonDetailItem {

    private String title;

    public Header(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public PokemonDetailItemType getType() {
        return PokemonDetailItemType.HEADER;
    }
}
