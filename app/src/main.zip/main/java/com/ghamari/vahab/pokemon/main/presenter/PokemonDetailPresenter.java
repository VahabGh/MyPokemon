package com.ghamari.vahab.pokemon.main.presenter;

import com.ghamari.vahab.pokemon.main.model.GetDataService;
import com.ghamari.vahab.pokemon.main.model.Pokemon;
import com.ghamari.vahab.pokemon.main.model.PokemonData;
import com.ghamari.vahab.pokemon.main.model.RetrofitClientInstance;
import com.ghamari.vahab.pokemon.main.view.PokemonDetailFragment;
import com.ghamari.vahab.pokemon.main.view.PokemonDetailView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by VahabGh on 5/28/2019.
 */
public class PokemonDetailPresenter {

    private PokemonDetailView view;

    public PokemonDetailPresenter(PokemonDetailView view) {
        this.view = view;
    }

    public void getPokemonDetail(String pokemonUrl) {

        view.showProgress();
        GetDataService service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        Call<Pokemon> call = service.getPokemonById(getIdFromUrl(pokemonUrl));

        call.enqueue(new Callback<Pokemon>() {
            @Override
            public void onResponse(Call<Pokemon> call, Response<Pokemon> response) {
                if (response.isSuccessful())
                    view.setPokemonDetail(response.body());
                view.hideProgress();
            }

            @Override
            public void onFailure(Call<Pokemon> call, Throwable t) {
                view.onFailed(t.toString());
                view.hideProgress();
            }
        });

    }

    private int getIdFromUrl(String pokemonUrl) {
        String[] items = pokemonUrl.split("/");
        return Integer.parseInt(items[items.length-1]);
    }
}
