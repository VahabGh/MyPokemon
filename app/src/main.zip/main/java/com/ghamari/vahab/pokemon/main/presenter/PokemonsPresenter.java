package com.ghamari.vahab.pokemon.main.presenter;

import android.widget.Toast;

import com.ghamari.vahab.pokemon.main.model.GetDataService;
import com.ghamari.vahab.pokemon.main.model.Pokemon;
import com.ghamari.vahab.pokemon.main.model.PokemonData;
import com.ghamari.vahab.pokemon.main.model.RetrofitClientInstance;
import com.ghamari.vahab.pokemon.main.view.MainActivity;
import com.ghamari.vahab.pokemon.main.view.PokemonsView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by VahabGh on 5/28/2019.
 */
public class PokemonsPresenter {

    private PokemonsView view;

    public PokemonsPresenter(PokemonsView view) {
        this.view = view;
    }

    public void getAllPokemons() {
        view.showProgress();
        GetDataService service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        Call<PokemonData> call = service.getAllPokemons();
        call.enqueue(new Callback<PokemonData>() {
            @Override
            public void onResponse(Call<PokemonData> call, Response<PokemonData> response) {
                if (response.isSuccessful())
                    view.success(response.body().getPokemonList());
                view.hideProgress();
            }

            @Override
            public void onFailure(Call<PokemonData> call, Throwable t) {
                view.failed(t.toString());
                view.hideProgress();
            }
        });
    }

}
