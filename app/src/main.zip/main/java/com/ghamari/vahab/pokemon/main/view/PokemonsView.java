package com.ghamari.vahab.pokemon.main.view;

import com.ghamari.vahab.pokemon.main.model.Pokemon;

import java.util.List;

/**
 * Created by VahabGh on 5/28/2019.
 */
public interface PokemonsView<T> extends BaseView<T> {
    void success(List<Pokemon> pokemons);
    void failed(String data);
}
