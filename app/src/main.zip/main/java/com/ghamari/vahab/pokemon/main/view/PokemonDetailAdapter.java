package com.ghamari.vahab.pokemon.main.view;

import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import com.ghamari.vahab.pokemon.main.model.PokemonDetailItem;

import java.util.List;

/**
 * Created by VahabGh on 5/29/2019.
 */
public class PokemonDetailAdapter extends RecyclerView.Adapter<PokemonDetailItemViewHolder> {

    private List<PokemonDetailItem> pokemonDetailItems;

    private PokemonDetailAdapter(List<PokemonDetailItem> pokemonDetailItems) {
        this.pokemonDetailItems = pokemonDetailItems;
    }

    @Override
    public PokemonDetailItemViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return null;
    }

    @Override
    public void onBindViewHolder(PokemonDetailItemViewHolder pokemonDetailItemViewHolder, int i) {
        PokemonDetailItem pokemonDetailItem = pokemonDetailItems.get(i);
        pokemonDetailItemViewHolder.bind(pokemonDetailItem);
    }

    @Override
    public int getItemCount() {
        return pokemonDetailItems.size();
    }
}
